public class Livro {
    //    Implemente a classe Livro, conforme o diagrama a seguir. No programa principal, crie dois
    //    objetos da classe Livro.
    public Livro(String titulo, String autor, int num_paginas) {
        this.titulo = titulo;
        this.autor = autor;
        this.num_paginas = num_paginas;
    }

    String titulo;
    String autor;
    int num_paginas;
}
